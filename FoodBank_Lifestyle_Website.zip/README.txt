FoodBank Lifestyle Website
------------------------------
How to host:
1. Go to https://netlify.com or https://vercel.com
2. Create an account and drag-and-drop this folder to deploy the website.
